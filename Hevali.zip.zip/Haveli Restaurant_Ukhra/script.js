// ===== HERO SLIDER =====
const slides = document.querySelectorAll(".slide");
let sIndex = 0;

function changeSlide(){
    slides.forEach(slide => slide.classList.remove("active"));
    slides[sIndex].classList.add("active");
    sIndex = (sIndex + 1) % slides.length;
}

setInterval(changeSlide, 4000);

// ===== SCROLL TO LOGIN =====
function scrollToLogin(){
    document.getElementById("login").scrollIntoView({
        behavior: "smooth"
    });
}

// ===== GALLERY SLIDESHOW =====
const galleryImages = [
    "images/gallery/g1.jpg",
    "images/gallery/g2.jpg",
    "images/gallery/g3.jpg",
    "images/gallery/g4.jpg",
    "images/gallery/g5.jpg"
];

let gIndex = 0;
const gImg = document.getElementById("gallery-img");

function changeGallery(){
    gImg.src = galleryImages[gIndex];
    gIndex = (gIndex + 1) % galleryImages.length;
}

setInterval(changeGallery, 3000);
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSheet();
  var data = JSON.parse(e.postData.contents);

  sheet.appendRow([
    data.name,
    data.email,
    data.phone,
    data.address,
    new Date()
  ]);

  return ContentService.createTextOutput("Success");
}
document.getElementById("orderForm").addEventListener("submit", function(e){
e.preventDefault();

fetch("https://script.google.com/macros/s/AKfycbxIwM0v3NqxxizXvdTORBhhAXb_EzeI8V1HT0f_lijfI1U2QfynoqeLXCnQPc_GWxnZFw/exec", {
method: "POST",
body: JSON.stringify({
name: document.getElementById("name").value,
email: document.getElementById("email").value,
phone: document.getElementById("phone").value,
address: document.getElementById("address").value
})
})
.then(res => alert("Order Sent Successfully!"))
.catch(err => alert("Error!"));
});